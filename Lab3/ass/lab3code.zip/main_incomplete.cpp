// Author: SID 500490778
// Date: 8/22

/*
This file runs a comparision between using a hash table vs a vector table for mapping an occupancy map
The time to test all points is compared by running through all test points
Required to include .h and .cpp files of includes below. Required occupancy and 
not occupied observation text files in the form int, int on each line.
*/


#include "OccupancyMapBase.h"
#include "OccupancyMapVec.h" 
#include "OccupancyMapHash.h"
#include <iostream>

//-----------------------------------------------------------------------------
int main()
{

  //test for vector approach
  {
    COccupancyMapVec VecMap;
    VecMap.EvalPerformance( "ExampleObservations_Small.txt", "ExampleNotObserved_Small.txt" );
  }


  // test for Hashing approach
  {
    COccupancyMapHash HashMap;
    HashMap.EvalPerformance( "ExampleObservations_Small.txt", "ExampleNotObserved_Small.txt" );
  }

  return 0;
}

