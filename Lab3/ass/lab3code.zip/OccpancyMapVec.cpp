//Author: 500490778
//Date: 8/22

/*
Inhertiance class from COccupancyMapBase
*/

#include "OccupancyMapVec.h"

#include <iostream>
#include <string>
#include <utility>        // std::pair
#include <vector>



//Initilises class
COccupancyMapVec::COccupancyMapVec() 
  : _Name("Vector approach") {};

//returns the name of approach from user
std::string COccupancyMapVec::GetNameOfApproach() {
  return _Name;
};

// adds occupied location to vector occupancy map
void COccupancyMapVec::AddOccupiedLocation(std::pair<int,int> Location) {
  mObservedPoints.push_back(Location);
};

// adds not occupied location to vector map
void COccupancyMapVec::AddNotOccupiedLocation(std::pair<int,int> Location) {
  mNotObservedPoints.push_back(Location);
};

// checks vector map for if a location is present
bool COccupancyMapVec::CheckIsOccupied( std::pair<int,int> Location ) {

  bool IsOcc = false; //assume false

  //searches for location in vector map, returns true if location found
  if(std::find(mObservedPoints.begin(), mObservedPoints.end(), Location) != mObservedPoints.end()) {
    IsOcc = true;
  }

  return IsOcc;
};