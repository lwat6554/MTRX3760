// Author: 500490778
// Date: 8/23

/*
COccupancyMapHash is a class that inhertiances from the COccupancyMapBase class
It creates a hash table to store observed/not observed locations. This was done in a format 
<key, hash>. The key is created by the MakeKey method which applies a function to the two 
ints for the location to create a unique double key. 
The class is able to add to the observed/not observed hash maps and check if a location 
is occupied
*/


#ifndef _OCCUPANCYMAPHASH_H
#define _OCCUPANCYMAPHASH_H

#include "OccupancyMapBase.h"

class COccupancyMapHash: public COccupancyMapBase 
{
   public:

    COccupancyMapHash();
    ~COccupancyMapHash(){};

    // Return the name of the approach as a string, for display purposes
    std::string GetNameOfApproach();

    // Add a location observed as occupied to the map
    void AddOccupiedLocation(std::pair<int,int> Location);
    
    // Add a location observed as not occupided to the map
    void AddNotOccupiedLocation(std::pair<int,int> Location);

    // Check if a location is occupied
    bool CheckIsOccupied( std::pair<int,int> Location);

    

  private:
    std::string _Name; //name of mapping method

    //hash table format, <key, hash>
    std::unordered_map<double, double> _ObservedMap;
    std::unordered_map<double, double> _NotObservedMap;

    //key for unordered map, function that takes two ints and outputs a unique key for map 
    double MakeKey(std::pair<int,int> Location);
};


#endif