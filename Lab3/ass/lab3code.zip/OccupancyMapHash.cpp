// Author: 500490778
// Date: 31/8/23

/*
Inhertiance class from COccupancyMapBase
*/


#include "OccupancyMapHash.h"

#include <iostream>
#include <string>
#include <utility>        // std::pair
#include <vector>

//initilise class, give it a name
COccupancyMapHash::COccupancyMapHash() 
    :_Name("Hash table-based approach") {};


// Return the name of the approach as a string, for display purposes
std::string COccupancyMapHash::GetNameOfApproach() {
    return _Name;
};

//returns unique key from function with two ints 
double COccupancyMapHash::MakeKey(std::pair<int,int> Location) {
    //ints between 0-2047, a/2048 + b creates unique key
    return ((double)Location.first/2048 + (double)Location.second);
};

// Add a location observed as occupied to the map
void COccupancyMapHash::AddOccupiedLocation(std::pair<int,int> Location) {
    //adds value into map, map[key] = hash
    _ObservedMap[MakeKey(Location)] = std::hash<double>()(MakeKey(Location));
};
    
// Add a location observed as not occupided to the map
void COccupancyMapHash::AddNotOccupiedLocation(std::pair<int,int> Location) {
    //adds value into map, map[key] = hash
    _NotObservedMap[MakeKey(Location)] = std::hash<double>()(MakeKey(Location));
};


// Check if a location is occupied
bool COccupancyMapHash::CheckIsOccupied( std::pair<int,int> Location ) {

    //output check
    bool check = true;

    //checks if key has a hash, if not return false
    if(_ObservedMap.find(MakeKey(Location)) == _ObservedMap.end()) {
        check = false;
    }

    return check;
};

