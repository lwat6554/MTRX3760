// Author: 500490778
// Date: 8/23

/*
COccupancyMapVec is a class that inhertiances from the COccupancyMapBase class
It creates a vector of pairs to store observed/not observed locations in a ,int,int> format.
The class is able to add to the observed/not observed vector maps and check if a location 
is occupied from the vector map
*/

#ifndef _OCCUPANCYMAPVEC_H
#define _OCCUPANCYMAPVEC_H

#include "OccupancyMapBase.h"

class COccupancyMapVec: public COccupancyMapBase
{
  public:

    COccupancyMapVec();
    ~COccupancyMapVec(){};

     // Return the name of the approach as a string, for display purposes
    std::string GetNameOfApproach();

    // Add a location observed as occupied to the map
    void AddOccupiedLocation(std::pair<int,int> Location);
    
    // Add a location observed as not occupided to the map
    void AddNotOccupiedLocation(std::pair<int,int> Location);

    // Check if a location is occupied
    bool CheckIsOccupied( std::pair<int,int> Location );

  private:
    std::string _Name;
};


#endif